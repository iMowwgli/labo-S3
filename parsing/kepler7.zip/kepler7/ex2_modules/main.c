/*
 * KEPLER-7 :: Mission 2 - Diagnostic des modules (JSON plat)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog -lcjson
 * Teste   : ../moulinette.sh ex2
 *
 * Usage : ./prog modules.json   (racine = tableau d'objets)
 * Pour chaque module valide : [<etat>] <nom> (<energie %.2f> kW)
 *   + " !! CRITIQUE" si etat == "HS" ET critique == true
 * Puis : Energie totale : <%.2f> kW
 *        Modules critiques HS : <K>
 * Module invalide (champ manquant / mauvais type) -> ignore (message stderr libre).
 * Fichier illisible -> return 1. JSON invalide ou racine pas un tableau -> stderr, return 2.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cjson/cJSON.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
