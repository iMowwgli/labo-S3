/*
 * KEPLER-7 :: Mission 2 - La boite noire (logs + sscanf)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog
 * Teste   : ../moulinette.sh ex2
 * Autorise : stdio.h, stdlib.h, string.h, ctype.h (pas de lib externe)
 *
 * Usage : ./prog journal.log
 * Ligne valide :  AAAA-MM-JJ HH:MM:SS [NIVEAU] module: message
 *   NIVEAU parmi INFO, WARN, ERROR (majuscules exactes).
 *   module = tout jusqu'au 1er ':' qui DOIT etre present.
 * Ligne vide -> ignoree.  Toute autre ligne -> invalide.  (\r\n possibles)
 * Affiche :
 *   INFO : n
 *   WARN : n
 *   ERROR : n
 *   Lignes invalides : n
 *   Premiere erreur : <HH:MM:SS> <module>: <message>    (ou "aucune")
 * Fichier illisible -> stderr, return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
