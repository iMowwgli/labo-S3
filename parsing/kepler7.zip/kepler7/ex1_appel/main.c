/*
 * KEPLER-7 :: Mission 1 - L'appel de l'equipage (CSV)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog -lcjson
 * Teste   : ../moulinette.sh ex1
 *
 * Usage : ./prog equipage.csv
 * Affiche :
 *   Equipage : N membre(s)
 *   Oxygene critique (< 30) : K
 *   - <nom> (<oxygene>%)        <- une ligne par membre critique, ordre du fichier
 * Regles : 1re ligne = en-tete. Champs separes par ',' + espaces eventuels.
 *          Lignes vides ignorees. Fins de ligne \n ou \r\n.
 * Fichier illisible -> message sur stderr, rien sur stdout, return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cjson/cJSON.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
