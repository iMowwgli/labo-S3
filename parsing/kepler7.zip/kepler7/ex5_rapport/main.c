/*
 * KEPLER-7 :: Mission 5 - Le rapport de bord (CSV -> JSON)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog -lcjson
 * Teste   : ../moulinette.sh ex5
 *
 * Usage : ./prog equipage.csv
 * Construit avec cJSON_Create* / cJSON_Add* puis affiche avec cJSON_PrintUnformatted :
 * {"station":"Kepler-7",
 *  "equipage":[{"nom":..,"role":..,"age":<int>,"oxygene":<int>}, ...],
 *  "critiques":[<noms avec oxygene < 30>],
 *  "oxygene_moyen":<moyenne, 0 si aucun membre>}
 * (sur UNE seule ligne). Fichier illisible -> return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cjson/cJSON.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
