	$(CC) main.c
all: main
