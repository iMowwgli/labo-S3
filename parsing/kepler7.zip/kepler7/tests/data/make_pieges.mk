URL = http://kepler7.space:8080
NOM=k7

all: $(NOM).bin
	curl $(URL)/status
	echo $(INCONNUE)ok $(NOM)$(NOM)
