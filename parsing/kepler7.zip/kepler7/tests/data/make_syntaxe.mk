URL = http://kepler7.space:8080
all:
	curl $(URL)/status
	echo $(INCONNUE)ok

n importe quoi
