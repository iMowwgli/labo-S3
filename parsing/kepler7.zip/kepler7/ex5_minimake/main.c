/*
 * KEPLER-7 :: Mission 5 - Mini-Minimake (Makefile)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog
 * Teste   : ../moulinette.sh ex5
 * Autorise : stdio.h, stdlib.h, string.h, ctype.h (pas de lib externe)
 *
 * Usage : ./prog Makefile
 * Lignes :
 *   - vide ou commencant par '#' (apres espaces) : ignoree
 *   - commencant par TAB : commande de la derniere regle
 *     (si la derniere ligne utile n'est ni une regle ni une commande ->
 *      stderr "Erreur ligne N : commande sans regle", return 2)
 *   - contient '=' avant tout ':'  : variable  NOM = valeur
 *   - contient ':'                 : regle     cible: deps
 *   - sinon : stderr "Erreur ligne N : syntaxe", return 2
 * Tout est trim (espaces, \r). Affiche APRES avoir tout lu :
 *   Variables : N
 *   NOM = valeur                      (ordre du fichier, non expanse)
 *   Regle <cible> : <deps expansees>  ou "(aucune dependance)"
 *     > <commande expansee>           (2 espaces, '>', 1 espace)
 * Expansion : chaque $(NOM) est remplace par sa valeur, "" si inconnue.
 * Fichier illisible -> return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
