/*
 * KEPLER-7 :: BONUS 4 - Le parseur JSON (boss final)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog
 * Teste   : ../moulinette.sh b4
 * Autorise : stdio.h, stdlib.h, string.h, ctype.h (pas de lib externe)
 *
 * Usage : ./prog rapport.json
 * Le fichier doit contenir EXACTEMENT un objet JSON plat :
 *   { "cle": valeur, ... }  avec valeur = string | nombre | true | false | null
 *   (pas d'objet ni de tableau imbrique, pas de virgule finale, rien apres le '}')
 *   nombre = -? chiffres ( . chiffres )?   string = comme au lexer (brut)
 * Si valide : une ligne par cle, ordre du fichier :
 *   <cle> (<string|number|bool|null>) : <valeur brute>
 *   puis  Total : N cle(s)
 * Si invalide : RIEN sur stdout, stderr "Erreur : JSON invalide", return 2.
 *   => il faut tout valider AVANT d'afficher.
 * Fichier illisible -> return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
