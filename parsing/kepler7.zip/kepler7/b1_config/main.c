/*
 * KEPLER-7 :: BONUS 1 - Le fichier de config (INI)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog
 * Teste   : ../moulinette.sh b1
 * Autorise : stdio.h, stdlib.h, string.h, ctype.h (pas de lib externe)
 *
 * Usage : ./prog station.ini              -> liste tout
 *         ./prog station.ini section.cle  -> affiche seulement la valeur
 * Format : [section]   cle = valeur   (espaces autour a retirer)
 *   - lignes vides et lignes commencant par ';' ou '#' ignorees
 *   - cle avant toute section -> section "global"
 *   - la cle s'arrete au PREMIER '=' (la valeur peut contenir '=')
 * Liste : une ligne "section.cle=valeur" par cle, ordre du fichier, au fil de la lecture.
 * Requete : affiche la valeur de la 1re occurrence, return 0.
 *           Absente -> stderr "Cle introuvable : ...", return 3.
 * Ligne invalide (ni section, ni cle=valeur, ou '[' sans ']') :
 *   stderr "Erreur ligne N", return 2 (ce qui a deja ete affiche reste affiche).
 * Fichier illisible -> return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
