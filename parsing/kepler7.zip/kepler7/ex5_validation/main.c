/*
 * KEPLER-7 :: Mission 5 - Le validateur (schema)
 * Compile (depuis kepler7/) :
 *   gcc -Wall -Wextra -Werror -std=c99 -pedantic -Ilib ex5_validation/main.c lib/cJSON.o -o ex5_validation/prog -lm
 *   (ou simplement : ./moulinette.sh ex5)
 *
 * Usage : ./prog journal.json   (racine = tableau)
 * Schema d'une entree (verifier DANS CET ORDRE, afficher le 1er champ fautif) :
 *   nom     : string non vide
 *   role    : string parmi commandant, ingenieur, medecin, pilote, biologiste
 *   age     : nombre ENTIER entre 18 et 70 inclus
 *   oxygene : nombre entre 0 et 100 inclus
 * Si l'entree n'est pas un objet : champ fautif = "objet".
 * Affiche :  #<i> OK   ou   #<i> INVALIDE : <champ>
 * Puis :     Bilan : <V>/<N> valide(s)
 * return 0 si tout est valide, 1 sinon, 2 si JSON invalide / racine pas un tableau.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "cJSON.h"   /* bibliotheque fournie : lib/cJSON.h */

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
