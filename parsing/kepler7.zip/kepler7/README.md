# KEPLER-7 — TP parsing de données structurées

L'IA de bord ORBIT a planté. Tu es le dernier ingénieur réveillé.
Comme au TP de mardi : du CSV **à la main**, et du JSON **avec une bibliothèque fournie** (cJSON, dans lib/).

## Installation
    sudo apt install build-essential valgrind

## Missions (notées)
    ex1_appel/       CSV à la main  -> fgets, strtok_r, trim
    ex2_journal/     logs à la main -> sscanf, %[...], %n
    ex3_modules/     JSON + cJSON   -> Parse, ArrayForEach, Is*
    ex4_capteurs/    JSON imbriqué  -> objets dans tableaux dans objet
    ex5_validation/  schéma         -> valider avant d'exploiter
    ex6_rapport/     CSV -> JSON    -> les deux à la fois !

## Bonus (parsing à la main, pour aller plus loin)
    b1_config/  INI     b2_lexer/  tokens JSON
    b3_minimake/ Makefile   b4_json/  parseur JSON récursif

La consigne exacte est en haut de chaque main.c.

## Moulinette
    ./moulinette.sh          # missions ex1 à ex6, note /20
    ./moulinette.sh ex3      # une mission
    ./moulinette.sh bonus    # les bonus
    ./moulinette.sh -v ex3   # diffs complets

cJSON (lib/) : licence MIT, Dave Gamble et contributeurs.
