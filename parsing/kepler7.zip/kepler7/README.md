# KEPLER-7 — TP parsing de données structurées

L'IA de bord ORBIT a planté. Tu es le dernier ingénieur réveillé.
Pour relancer la station, il faut relire ses données : CSV et JSON.

## Installation (Ubuntu)
    sudo apt install libcjson-dev valgrind

## Missions
    ex1_appel/       CSV           -> fgets, strtok_r, trim
    ex2_modules/     JSON plat     -> cJSON_Parse, ArrayForEach, Is*
    ex3_capteurs/    JSON imbriqué -> objets dans tableaux dans objet
    ex4_validation/  schéma        -> valider avant d'exploiter
    ex5_rapport/     CSV -> JSON   -> cJSON_Create*, PrintUnformatted

La consigne exacte est en haut de chaque main.c.

## Moulinette
    ./moulinette.sh          # tout
    ./moulinette.sh ex3      # une mission
    ./moulinette.sh -v ex3   # diffs complets

Note /20 : 3 pts de tests + 1 pt « code propre » (0 fuite valgrind, 0 erreur critique) par mission.
