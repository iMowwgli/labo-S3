# KEPLER-7 — TP parsing de données structurées (C pur)

L'IA de bord ORBIT a planté. Tu es le dernier ingénieur réveillé.
Ses données sont intactes : CSV, logs, INI, Makefile, JSON.
Pas de bibliothèque externe : stdio.h, stdlib.h, string.h, ctype.h.

## Missions
    ex1_appel/      CSV        -> fgets, strtok_r, trim
    ex2_journal/    logs       -> sscanf, %[...], %n
    ex3_config/     INI        -> strchr, sections, 1er '='
    ex4_lexer/      lexer JSON -> automate caractère par caractère
    ex5_minimake/   Makefile   -> règles, variables, $(VAR)
    ex6_json/       parseur    -> descente récursive

La consigne exacte est en haut de chaque main.c.

## Moulinette
    ./moulinette.sh          # tout
    ./moulinette.sh ex4      # une mission
    ./moulinette.sh -v ex4   # diffs complets

3 pts de tests + 1 pt « code propre » (0 fuite valgrind, 0 erreur critique) par mission, ramené sur 20.
Optionnel : sudo apt install valgrind
