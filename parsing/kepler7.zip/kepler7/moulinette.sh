#!/usr/bin/env bash
# ============================================================
#  MOULINETTE KEPLER-7  -  TP Parsing de donnees structurees
#  Usage : ./moulinette.sh            (tous les exercices)
#          ./moulinette.sh ex3        (un seul exercice)
#          ./moulinette.sh -v ex2     (affiche les diffs complets)
# ============================================================
cd "$(dirname "$0")" || exit 1

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; M=$'\e[35m'; C=$'\e[36m'; B=$'\e[1m'; D=$'\e[2m'; N=$'\e[0m'
CFLAGS="-Wall -Wextra -Werror -std=c99 -pedantic -g"
LIBS="-lcjson"
VERBOSE=0
[ "$1" = "-v" ] && { VERBOSE=1; shift; }
FILTER="$1"

HAS_VG=0; command -v valgrind >/dev/null && HAS_VG=1
if [ ! -f /usr/include/cjson/cJSON.h ]; then
  echo "${R}cJSON introuvable.${N} Installe-le :  ${B}sudo apt install libcjson-dev${N}"; exit 1
fi

echo "${M}${B}"
echo "   _  _____ ___ _    ___ ___      ____ "
echo "  | |/ / __| _ \\ |  | __| _ \\ ___|__  |"
echo "  | ' <| _||  _/ |__| _||   /|___| / / "
echo "  |_|\\_\\___|_| |____|___|_|_\\     /_/  "
echo "${N}${D}  moulinette - parsing de donnees structurees${N}"
echo

total=0; max=0
declare -a RESUME

# ---------- analyse statique : les pieges classiques ----------
analyse() {
  local f="$1" w=0
  local code; code=$(sed -e 's://.*$::' "$f")   # sans commentaires //
  warn() { echo "    ${Y}⚠${N} $1"; w=$((w+1)); }
  crit() { echo "    ${R}✖${N} $1"; CRIT=$((CRIT+1)); w=$((w+1)); }
  if grep -q 'cJSON_Parse' <<<"$code" && ! grep -q 'cJSON_Delete' <<<"$code"; then
    crit "cJSON_Parse sans cJSON_Delete : tout l'arbre fuit."; fi
  if grep -q 'cJSON_Create\(Object\|Array\)' <<<"$code" && ! grep -q 'cJSON_Delete' <<<"$code"; then
    crit "Arbre cree avec cJSON_Create* mais jamais cJSON_Delete."; fi
  if grep -q 'cJSON_Print' <<<"$code" && ! grep -q 'free *(' <<<"$code"; then
    crit "cJSON_Print* alloue une chaine : il faut la free()."; fi
  if grep -q 'fopen' <<<"$code" && ! grep -q 'fclose' <<<"$code"; then
    crit "fopen sans fclose."; fi
  if grep -q 'fopen' <<<"$code" && ! grep -Eq '(if *\( *!|== *NULL|!= *NULL)' <<<"$code"; then
    warn "Le retour de fopen/malloc/cJSON_Parse ne semble jamais compare a NULL."; fi
  if grep -q 'cJSON_GetArrayItem' <<<"$code"; then
    warn "OPTI : cJSON_GetArrayItem est en O(i) (liste chainee) -> O(n^2) en boucle. Utilise cJSON_ArrayForEach."; fi
  if grep -Eq 'for *\([^;]*;[^;]*cJSON_GetArraySize' <<<"$code"; then
    warn "OPTI : cJSON_GetArraySize dans la condition du for = recalcule (O(n)) a chaque tour."; fi
  if grep -Eq 'for *\([^;]*;[^;]*strlen' <<<"$code"; then
    warn "OPTI : strlen dans la condition du for = O(n^2). Stocke la longueur avant."; fi
  if grep -Eq 'cJSON_GetObjectItem *\(' <<<"$code"; then
    warn "cJSON_GetObjectItem ignore la casse : prefere cJSON_GetObjectItemCaseSensitive."; fi
  if grep -Eq '(valuestring|valuedouble|valueint)' <<<"$code" && ! grep -q 'cJSON_Is' <<<"$code"; then
    crit "valuestring/valuedouble lus sans aucun cJSON_Is* : segfault si le type est faux."; fi
  if grep -q 'valueint' <<<"$code"; then
    warn "valueint tronque les decimaux : prefere valuedouble (et verifie si c'est un entier)."; fi
  if grep -Eq '\bstrtok *\(' <<<"$code"; then
    warn "strtok n'est pas reentrant : strtok_r est plus sur (et attention aux champs vides)."; fi
  if grep -Eq '\bgets *\(' <<<"$code"; then
    crit "gets() est interdit (overflow). Utilise fgets."; fi
  [ $w -eq 0 ] && echo "    ${G}✔ Rien a signaler.${N}"
}

for exdir in ex*_*/; do
  ex=${exdir%/}
  [ -n "$FILTER" ] && [[ "$ex" != "$FILTER"* ]] && continue
  echo "${C}${B}━━━ $ex ━━━${N}"
  src="$ex/main.c"; bin="$ex/prog"
  ntests=$(ls -d tests/$ex/*/ 2>/dev/null | wc -l)
  max=$((max+4))
  if ! gcc $CFLAGS "$src" -o "$bin" $LIBS 2>/tmp/k7_cc.log; then
    echo "  ${R}✖ Compilation echouee${N} (flags : $CFLAGS)"
    head -15 /tmp/k7_cc.log | sed 's/^/    /'
    RESUME+=("$ex|0|4|compilation")
    echo; continue
  fi
  pass=0; vgerr=0; CRIT=0
  for t in tests/$ex/*/; do
    name=$(basename "$t")
    # shellcheck disable=SC2046
    out=$(timeout 5 "./$bin" $(cat "$t/args") 2>/dev/null); code=$?
    exp_code=$(cat "$t/code")
    if [ "$out" == "$(cat "$t/expected")" ] && [ "$code" == "$exp_code" ]; then
      echo "  ${G}✔${N} $name"; pass=$((pass+1))
    else
      if [ $code -eq 124 ]; then why="timeout (boucle infinie ?)";
      elif [ $code -ge 128 ]; then why="crash (signal $((code-128)) - segfault ?)";
      elif [ "$code" != "$exp_code" ]; then why="code de retour $code au lieu de $exp_code";
      else why="sortie differente"; fi
      echo "  ${R}✖${N} $name ${D}($why)${N}"
      if [ "$out" != "$(cat "$t/expected")" ]; then
        diff <(echo "$out") "$t/expected" | { [ $VERBOSE -eq 1 ] && cat || head -6; } \
          | sed -e "s/^</    ${R}toi     ${N}/" -e "s/^>/    ${G}attendu ${N}/" -e '/^[0-9]/d' -e '/^---/d'
      fi
    fi
    if [ $HAS_VG -eq 1 ]; then
      # shellcheck disable=SC2046
      timeout 20 valgrind -q --leak-check=full --errors-for-leak-kinds=definite,indirect,possible \
        --error-exitcode=42 "./$bin" $(cat "$t/args") >/dev/null 2>/tmp/k7_vg.log
      if [ $? -eq 42 ]; then
        vgerr=$((vgerr+1))
        echo "    ${R}valgrind :${N} $(grep -m1 -E 'definitely|Invalid|uninitialised|indirectly|possibly' /tmp/k7_vg.log | sed 's/==[0-9]*== //')"
      fi
    fi
  done
  echo "  ${B}Analyse du code :${N}"
  analyse "$src"
  pts=$(( pass * 3 / ntests ))
  clean=0; [ $vgerr -eq 0 ] && [ $CRIT -eq 0 ] && [ $pass -gt 0 ] && clean=1
  pts=$((pts+clean))
  total=$((total+pts))
  note="$pass/$ntests tests"; [ $HAS_VG -eq 1 ] && note="$note, valgrind: $vgerr erreur(s)"
  RESUME+=("$ex|$pts|4|$note")
  echo
done

echo "${M}${B}━━━━━━━━━━ BILAN ━━━━━━━━━━${N}"
for r in "${RESUME[@]}"; do
  IFS='|' read -r e p m n <<<"$r"
  printf "  %-16s %s/%s  ${D}%s${N}\n" "$e" "$p" "$m" "$n"
done
[ $max -gt 0 ] && echo "  ${B}Note : $total / $max${N}  ${D}(3 pts de tests + 1 pt code propre par exo)${N}"
[ $HAS_VG -eq 0 ] && echo "  ${Y}Astuce : sudo apt install valgrind pour la detection de fuites.${N}"
