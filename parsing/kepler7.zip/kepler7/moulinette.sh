#!/usr/bin/env bash
# ============================================================
#  MOULINETTE KEPLER-7  -  TP Parsing de donnees structurees
#  Usage : ./moulinette.sh            (missions ex1 a ex6)
#          ./moulinette.sh ex3        (une seule mission)
#          ./moulinette.sh bonus      (missions bonus b1 a b4)
#          ./moulinette.sh -v ex2     (affiche les diffs complets)
# ============================================================
cd "$(dirname "$0")" || exit 1

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; M=$'\e[35m'; C=$'\e[36m'; B=$'\e[1m'; D=$'\e[2m'; N=$'\e[0m'
CFLAGS="-Wall -Wextra -Werror -std=c99 -pedantic -g"
LIBS="lib/cJSON.o -lm"
VERBOSE=0
[ "$1" = "-v" ] && { VERBOSE=1; shift; }
FILTER="$1"

HAS_VG=0; command -v valgrind >/dev/null && HAS_VG=1
command -v gcc >/dev/null || { echo "${R}gcc introuvable.${N} sudo apt install build-essential"; exit 1; }
# la bibliotheque fournie est compilee une fois, sans -Werror (ce n'est pas ton code)
if [ ! -f lib/cJSON.o ] || [ lib/cJSON.c -nt lib/cJSON.o ]; then
  gcc -c lib/cJSON.c -o lib/cJSON.o -std=c99 -O2 || { echo "${R}Compilation de lib/cJSON.c impossible${N}"; exit 1; }
fi

echo "${M}${B}"
echo "   _  _____ ___ _    ___ ___      ____ "
echo "  | |/ / __| _ \\ |  | __| _ \\ ___|__  |"
echo "  | ' <| _||  _/ |__| _||   /|___| / / "
echo "  |_|\\_\\___|_| |____|___|_|_\\     /_/  "
echo "${N}${D}  moulinette - parsing CSV a la main + JSON avec cJSON${N}"
echo

total=0; max=0
declare -a RESUME

# ---------- analyse statique : les pieges classiques ----------
analyse() {
  local f="$1" w=0
  local code; code=$(sed -e 's://.*$::' "$f")   # sans commentaires //
  warn() { echo "    ${Y}⚠${N} $1"; w=$((w+1)); }
  crit() { echo "    ${R}✖${N} $1"; CRIT=$((CRIT+1)); w=$((w+1)); }
  if grep -q 'fopen' <<<"$code" && ! grep -q 'fclose' <<<"$code"; then
    crit "fopen sans fclose."; fi
  if grep -Eq '\b(malloc|calloc|realloc|strdup)\b' <<<"$code" && ! grep -q 'free *(' <<<"$code"; then
    crit "Allocation sans aucun free."; fi
  if grep -Eq '\bgets *\(' <<<"$code"; then
    crit "gets() est interdit (overflow). Utilise fgets."; fi
  if grep -Eq '\b(strtok_r|strdup|getline)\b' <<<"$code" && ! grep -Eq '_POSIX_C_SOURCE|_DEFAULT_SOURCE|_GNU_SOURCE' "$f"; then
    crit "strtok_r/strdup/getline en -std=c99 : ajoute #define _POSIX_C_SOURCE 200809L avant les includes."; fi
  if grep -Eq '(==|!=) *"' <<<"$code"; then
    crit "Comparaison de chaine avec == : compare des ADRESSES. Utilise strcmp."; fi
  if grep -Eq '(\w+) *= *realloc *\( *\1 *,' <<<"$code"; then
    warn "p = realloc(p, ...) : si realloc echoue, l'ancien bloc fuit. Passe par un pointeur temporaire."; fi
  if grep -Eq '\bstrtok *\(' <<<"$code"; then
    warn "strtok n'est pas reentrant et fusionne les separateurs (a,,b -> 2 champs)."; fi
  if grep -Eq '\batoi *\(' <<<"$code"; then
    warn "atoi ne signale aucune erreur : strtol + endptr si la consigne demande de valider."; fi
  if grep -Eq '\bsscanf *\(' <<<"$code" && ! grep -Eq 'sscanf *\([^;]*\) *(!=|==|<|>)|= *sscanf|if *\( *sscanf' <<<"$code"; then
    crit "Le retour de sscanf n'est pas teste : il donne le nombre de champs lus."; fi
  if grep -Eq '%s' <<<"$(grep -E 'scanf' <<<"$code")"; then
    warn "%s sans largeur dans un scanf : overflow possible (%63s)."; fi
  if grep -Eq '\bstrncpy *\(' <<<"$code"; then
    warn "strncpy ne met pas de '\\\\0' si la source est trop longue : prefere snprintf(dst, size, \"%s\", src)."; fi
  if grep -Eq 'is(space|digit|alpha|alnum|upper|lower) *\( *\*?[a-z_]+(\[[^]]*\])? *\)' <<<"$code" && ! grep -q 'unsigned char' <<<"$code"; then
    warn "isdigit/isspace(char) : caste en (unsigned char), sinon comportement indefini sur les accents."; fi
  if grep -q 'cJSON_Parse' <<<"$code" && ! grep -q 'cJSON_Delete' <<<"$code"; then
    crit "cJSON_Parse sans cJSON_Delete : tout l'arbre fuit."; fi
  if grep -q 'cJSON_Create\(Object\|Array\)' <<<"$code" && ! grep -q 'cJSON_Delete' <<<"$code"; then
    crit "Arbre cree avec cJSON_Create* mais jamais cJSON_Delete."; fi
  if grep -q 'cJSON_Print' <<<"$code" && ! grep -q 'free *(' <<<"$code"; then
    crit "cJSON_Print* alloue une chaine : il faut la free()."; fi
  if grep -Eq '(valuestring|valuedouble|valueint)' <<<"$code" && ! grep -q 'cJSON_Is' <<<"$code"; then
    crit "valuestring/valuedouble lus sans aucun cJSON_Is* : segfault si le champ manque ou a le mauvais type."; fi
  if grep -Eq 'cJSON_GetObjectItem *\(' <<<"$code"; then
    warn "cJSON_GetObjectItem ignore la casse : prefere cJSON_GetObjectItemCaseSensitive."; fi
  if grep -q 'valueint' <<<"$code"; then
    warn "valueint tronque les decimaux : prefere valuedouble."; fi
  [ $w -eq 0 ] && echo "    ${G}✔ Rien a signaler.${N}"
}

if [ "$FILTER" = "bonus" ]; then DIRS=$(ls -d b[0-9]_*/); FILTER=""
elif [[ "$FILTER" == b* ]]; then DIRS=$(ls -d b[0-9]_*/)
else DIRS=$(ls -d ex[0-9]_*/); fi
for exdir in $DIRS; do
  ex=${exdir%/}
  [ -n "$FILTER" ] && [[ "$ex" != "$FILTER"* ]] && continue
  echo "${C}${B}━━━ $ex ━━━${N}"
  src="$ex/main.c"; bin="$ex/prog"
  ntests=$(ls -d tests/$ex/*/ 2>/dev/null | wc -l)
  max=$((max+4))
  if ! gcc $CFLAGS -Ilib "$src" -o "$bin" $LIBS 2>/tmp/k7_cc.log; then
    echo "  ${R}✖ Compilation echouee${N} (flags : $CFLAGS)"
    head -15 /tmp/k7_cc.log | sed 's/^/    /'
    RESUME+=("$ex|0|4|compilation")
    echo; continue
  fi
  pass=0; vgerr=0; CRIT=0
  for t in tests/$ex/*/; do
    name=$(basename "$t")
    # shellcheck disable=SC2046
    out=$(timeout 5 "./$bin" $(cat "$t/args") 2>/dev/null); code=$?
    exp_code=$(cat "$t/code")
    if [ "$out" == "$(cat "$t/expected")" ] && [ "$code" == "$exp_code" ]; then
      echo "  ${G}✔${N} $name"; pass=$((pass+1))
    else
      if [ $code -eq 124 ]; then why="timeout (boucle infinie ?)";
      elif [ $code -ge 128 ]; then why="crash (signal $((code-128)) - segfault ?)";
      elif [ "$code" != "$exp_code" ]; then why="code de retour $code au lieu de $exp_code";
      else why="sortie differente"; fi
      echo "  ${R}✖${N} $name ${D}($why)${N}"
      if [ "$out" != "$(cat "$t/expected")" ]; then
        diff <(echo "$out") "$t/expected" | { [ $VERBOSE -eq 1 ] && cat || head -6; } \
          | sed -e "s/^</    ${R}toi     ${N}/" -e "s/^>/    ${G}attendu ${N}/" -e '/^[0-9]/d' -e '/^---/d'
      fi
    fi
    if [ $HAS_VG -eq 1 ]; then
      # shellcheck disable=SC2046
      timeout 20 valgrind -q --leak-check=full --errors-for-leak-kinds=definite,indirect,possible \
        --error-exitcode=42 "./$bin" $(cat "$t/args") >/dev/null 2>/tmp/k7_vg.log
      if [ $? -eq 42 ]; then
        vgerr=$((vgerr+1))
        echo "    ${R}valgrind :${N} $(grep -m1 -E 'definitely|Invalid|uninitialised|indirectly|possibly' /tmp/k7_vg.log | sed 's/==[0-9]*== //')"
      fi
    fi
  done
  echo "  ${B}Analyse du code :${N}"
  analyse "$src"
  pts=$(( pass * 3 / ntests ))
  clean=0; [ $vgerr -eq 0 ] && [ $CRIT -eq 0 ] && [ $pass -gt 0 ] && clean=1
  pts=$((pts+clean))
  total=$((total+pts))
  note="$pass/$ntests tests"; [ $HAS_VG -eq 1 ] && note="$note, valgrind: $vgerr erreur(s)"
  RESUME+=("$ex|$pts|4|$note")
  echo
done

echo "${M}${B}━━━━━━━━━━ BILAN ━━━━━━━━━━${N}"
for r in "${RESUME[@]}"; do
  IFS='|' read -r e p m n <<<"$r"
  printf "  %-16s %s/%s  ${D}%s${N}\n" "$e" "$p" "$m" "$n"
done
if [ $max -gt 0 ]; then
  note=$(awk "BEGIN{printf \"%.1f\", $total*20/$max}")
  echo "  ${B}Total : $total / $max  ->  Note : $note / 20${N}  ${D}(3 pts de tests + 1 pt code propre par exo)${N}"
fi
[ $HAS_VG -eq 0 ] && echo "  ${Y}Astuce : sudo apt install valgrind pour la detection de fuites.${N}"
