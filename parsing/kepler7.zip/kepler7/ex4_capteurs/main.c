/*
 * KEPLER-7 :: Mission 4 - Les capteurs fous (JSON imbrique)
 * Compile (depuis kepler7/) :
 *   gcc -Wall -Wextra -Werror -std=c99 -pedantic -Ilib ex4_capteurs/main.c lib/cJSON.o -o ex4_capteurs/prog -lm
 *   (ou simplement : ./moulinette.sh ex4)
 *
 * Usage : ./prog capteurs.json
 * Racine = objet { "station": string, "releves": [ {id, type, seuil, valeurs[]} ] }
 * Pour chaque releve valide :
 *   <id> <type> : max <%.2f> / seuil <%.2f> -> ALERTE   (si max > seuil, sinon "ok")
 *   <id> <type> : aucune valeur                          (si valeurs est vide)
 * Puis : Station <station> : <K> alerte(s)
 * Releve invalide -> ignore. Attention : les valeurs peuvent etre negatives !
 * Fichier illisible -> return 1. JSON invalide / structure fausse -> return 2.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "cJSON.h"   /* bibliotheque fournie : lib/cJSON.h */

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
