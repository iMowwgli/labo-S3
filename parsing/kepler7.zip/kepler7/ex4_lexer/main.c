/*
 * KEPLER-7 :: Mission 4 - Le lexer (JSON -> tokens)
 * Compile : gcc -Wall -Wextra -Werror -std=c99 -pedantic main.c -o prog
 * Teste   : ../moulinette.sh ex4
 * Autorise : stdio.h, stdlib.h, string.h, ctype.h (pas de lib externe)
 *
 * Usage : ./prog fichier.json
 * Affiche un token par ligne, puis EOF :
 *   LBRACE RBRACE LBRACKET RBRACKET COLON COMMA TRUE FALSE NULL
 *   STRING(<contenu brut entre les guillemets, echappements \\x gardes tels quels>)
 *   NUMBER(<texte du nombre>)    nombre = -? chiffres ( . chiffres )?
 * Espaces, tabulations, retours a la ligne : ignores.
 * Erreur (caractere interdit, mot inconnu, chaine non fermee sur la ligne, nombre mal forme) :
 *   les tokens deja trouves restent affiches,
 *   stderr "Erreur lexicale ligne L colonne C" (debut du token fautif, 1 caractere = 1 colonne),
 *   return 2.
 * Fichier illisible -> return 1.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    /* TODO */
    return 0;
}
